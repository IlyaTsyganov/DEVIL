DEViL Standalone — Windows x64

Extract this archive, keep the Assets and Native folders next to DEViL.exe, and run DEViL.exe.
This framework-dependent build requires the .NET 10 Desktop Runtime.

The bundled DoomCollisionLayer.dll is a Vulkan layer for DOOM Eternal. The UI does not write to or terminate the game or DESRU. Viewer changes apply on the next game launch.

Bundled Eternal fonts retain their original ownership and terms; they are not relicensed by this project.
